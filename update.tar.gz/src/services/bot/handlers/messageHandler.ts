import { sendMessage, sendChatAction } from "@/lib/telegram";
import { getServerClient } from "@/lib/supabaseClient";
import { findOrCreateSession, appendMessage, listMessages } from "@/services/sessions";
import { runAnalyzerAgent, runSaleWriterAgent, runClientTranslatorAgent, RoleMessage } from "../ai/agents";
import { handleSearchDatabase } from "../actions/search";
import { handleSaveLead } from "../actions/leads";
import { handleGetPhotos } from "../actions/photos";
import { handleGetAgencyInfo } from "../actions/agency";
import { scheduleFollowup } from "../actions/followup";

function escapeHtml(text: string): string {
    return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export async function handleMessage(
    text: string,
    chatId: string,
    token: string,
    botId: string,
    userInfo: { username?: string | null; fullName?: string | null; phone?: string | null; language_code?: string | null },
    update?: any
) {
    try {
        console.log(`[Bot] Message from ${chatId}: ${text}`);

        // 0. HANDLE WEB_APP_DATA
        let manualPhone = "";
        const webAppData = update?.message?.web_app_data?.data;
        if (webAppData) {
            try {
                const data = JSON.parse(webAppData);
                console.log("[Bot] WebApp Data received:", data);
                
                if (data.action === 'book_now' || data.action === 'ask_about') {
                    // Treat this as a trigger for lead extraction or direct notification
                    if (data.phone) manualPhone = data.phone;
                    const phoneSuffix = data.phone ? `\n📞 Телефон: ${data.phone}` : '';
                    text = `Я интересуюсь объектом: ${data.title} (ID: ${data.unit_id}). ${data.action === 'book_now' ? 'ХОЧУ КУПИТЬ/ЗАБРОНИРОВАТЬ!' : 'Расскажи подробнее.'}${phoneSuffix}`;
                }
            } catch (e) {
                console.error("WebApp Data Parse Error:", e);
            }
        }

        // 0. REGISTER / UPDATE USER in Supabase (with Referral support)
        const supabase = getServerClient();
        
        // 0a. Check if user already exists to preserve role and referrer
        const { data: existingUser } = await supabase
            .from('users')
            .select('role, referrer_id, lang_code, manager_contact_id, is_support_mode')
            .eq('telegram_id', parseInt(chatId))
            .single();

        let referrer_id: number | null = existingUser?.referrer_id || null;
        let roleToSet = existingUser?.role || 'client';

        // --- NEW: MANAGER SUPPORT MODE (FORWARDING) ---
        if (existingUser && (existingUser.role === 'admin' || existingUser.role === 'founder' || existingUser.role === 'manager')) {
            if (existingUser.manager_contact_id) {
                const targetId = existingUser.manager_contact_id;
                try {
                    const prefix = `💬 <b>Сообщение от Администрации:</b>\n\n`;
                    await sendMessage(token, String(targetId), prefix + text, { parse_mode: 'HTML' });
                    await supabase.from('users').update({ manager_contact_id: null }).eq('telegram_id', parseInt(chatId));
                    return sendMessage(token, chatId, `✅ Сообщение отправлено пользователю <code>${targetId}</code>. Режим чата выключен.`, { parse_mode: 'HTML' });
                } catch (err: any) {
                    return sendMessage(token, chatId, `❌ Ошибка отправки: ${err.message}`);
                }
            }
        }

        if (!referrer_id && text.startsWith("/start ") && text.length > 7) {
            const refParam = text.split(" ")[1];
            const refId = parseInt(refParam);
            if (!isNaN(refId) && refId !== parseInt(chatId)) {
                referrer_id = refId;
                console.log(`[Bot] Referral detected! Referrer: ${referrer_id} for User: ${chatId}`);
                
                // Optional: Notify referrer
                sendMessage(token, String(referrer_id), `🎁 <b>Новый реферал!</b>\nПользователь @${userInfo.username || chatId} присоединился по вашей ссылке.`, { parse_mode: 'HTML' }).catch(() => {});
            }
        }

        await supabase.from('users').upsert({
            telegram_id: parseInt(chatId),
            username: userInfo.username,
            full_name: userInfo.fullName,
            lang_code: existingUser?.lang_code || userInfo.language_code || 'ru',
            role: roleToSet,
            referrer_id: referrer_id || undefined
        }, { 
            onConflict: 'telegram_id'
        });

        const sessionId = (await findOrCreateSession(botId, chatId)).id;

        // --- NEW: CLIENT SUPPORT MODE (FORWARDING TO ADMINS) ---
        if (existingUser && existingUser.role === 'client' && existingUser.is_support_mode) {
            const { data: staffMembers } = await supabase
                .from("users")
                .select("telegram_id, role")
                .in("role", ["founder", "admin", "manager"]);
            
            if (staffMembers && staffMembers.length > 0) {
                const name = userInfo.fullName || userInfo.username || "Client";
                const alertMsg = `📩 <b>СООБЩЕНИЕ ОТ КЛИЕНТА</b>\n\n👤 Юзер: @${userInfo.username || chatId}\n👤 Имя: ${escapeHtml(name)}\n🆔 ID: <code>${chatId}</code>\n\n📝 <b>Текст:</b> ${escapeHtml(text)}`;
                
                const recipients = staffMembers.filter(r => 
                    r.role === 'founder' || 
                    r.role === 'admin' || 
                    (r.role === 'manager' && String(r.telegram_id) === String(referrer_id))
                );

                for (const recipient of recipients) {
                    if (recipient.telegram_id) {
                        sendMessage(token, String(recipient.telegram_id), alertMsg, { 
                            parse_mode: 'HTML',
                            reply_markup: {
                                inline_keyboard: [[{ text: "✉️ Ответить", callback_data: `contactuser_${chatId}` }]]
                            }
                        }).catch(() => {});
                    }
                }
                
                await supabase.from('users').update({ is_support_mode: false }).eq('telegram_id', parseInt(chatId));
                return sendMessage(token, chatId, "✅ Ваше сообщение передано менеджеру. Скоро мы свяжемся с вами!");
            }
        }

        // 1. Save User Message
        await appendMessage({
            session_id: sessionId,
            bot_id: botId,
            role: "user",
            content: text,
            payload: { update }
        });

        // 1a. SPECIAL HANDLING FOR /START
        if (text.startsWith("/start")) {
            const initialLang = userInfo.language_code?.split('-')[0] || 'ru';
            const greetings: Record<string, string> = {
                ru: "👋 <b>Добро пожаловать!</b>\n\nЯ ваш интеллектуальный ассистент по недвижимости. Я помогу вам найти идеальный объект для жизни или инвестиций.\n\n<b>Что я умею:</b>\n— Поиск квартир и участков\n— Подбор вариантов по вашему бюджету\n— Ответы на вопросы о ВНЖ и налогах\n— Организация просмотров\n\nПросто напишите мне, что вы ищете (например: <i>\"Ищу квартиру 2+1 в Алании до 150к евро\"</i>) или откройте каталог ниже! 👇",
                en: "👋 <b>Welcome!</b>\n\nI am your intelligent Emedeo assistant. I'll help you find the perfect property for living or investment.\n\n<b>What I can do:</b>\n— Search for apartments and land\n— Match properties to your budget\n— Answer questions about residency and taxes\n— Organize viewings\n\nJust tell me what you're looking for (e.g., <i>\"Looking for a 2+1 apartment in Alanya under 150k Euro\"</i>) or open the catalog below! 👇",
                tr: "👋 <b>Hoş geldiniz!</b>\n\nBen sizin akıllı emlak asistanınızım. Yaşamak veya yatırım yapmak için mükemmel mülkü bulmanıza yardımcı olacağım.\n\n<b>Neler yapabilirim:</b>\n— Daire ve arsa arama\n— Bütçenize uygun mülk eşleştirme\n— Oturma izni ve vergiler hakkındaki soruları yanıtlama\n— Görüntüleme organize etme\n\nSadece ne aradığınızı söyleyin (örneğin: <i>\"Alanya'da 150 bin Euro'nun altında 2+1 daire arıyorum\"</i>) veya aşağıdaki kataloğu açın! 👇",
                de: "👋 <b>Willkommen!</b>\n\nIch bin Ihr intelligenter Immobilienassistent. Ich helfe Ihnen, die perfekte Immobilie zum Leben oder Investieren zu finden.\n\n<b>Was ich tun kann:</b>\n— Suche nach Wohnungen und Grundstücken\n— Passende Immobilien für Ihr Budget finden\n— Fragen zu Aufenthalt und Steuern beantworten\n— Besichtigungen organisieren\n\nSagen Sie mir einfach, was Sie suchen (z. B. <i>„Ich suche eine 2+1-Wohnung in Alanya unter 150.000 Euro“</i>) oder öffnen Sie den Katalog unten! 👇",
                es: "👋 <b>¡Bienvenido!</b>\n\nSoy su asistente inteligente de bienes raíces. Le ayudaré a encontrar la propiedad perfecta para vivir o invertir.\n\n<b>Qué puedo hacer:</b>\n— Buscar apartamentos и terrenos\n— Encontrar propiedades que se ajusten a su presupuesto\n— Responder preguntas sobre residencia e impuestos\n— Organizar visitas\n\nSimplemente dígame qué está buscando (por ejemplo: <i>\"Busco un apartamento 2+1 en Alanya por menos de 150.000 euros\"</i>) ¡o abra el catálogo a continuación! 👇",
                ar: "👋 <b>أهلاً بك!</b>\n\nأنا مساعدك الذكي للعقارات. سأساعدك في العثور على العقار المثالي للعيش أو الاستثمار.\n\n<b>ماذا يمكنني أن أفعل:</b>\n— البحث عن شقق وأراضي\n— مطابقة العقارات لميزانيتك\n— الإجابة على الأسئلة المتعلقة بالإقامة والضرائب\n— تنظيم المعاينات\n\nفقط أخبرني عما تبحث عنه (على سبيل المثال: <i>\"أبحث عن شقة 2+1 في ألانيا بأقل من 150 ألف يورو\"</i>) أو افتح الكتالوج أدناه! 👇",
                fr: "👋 <b>Bienvenue !</b>\n\nJe suis votre assistant immobilier intelligent. Je vous aiderai à trouver la propriété idéale pour vivre ou investir.\n\n<b>Ce que je peux faire :</b>\n— Rechercher des appartements et des terrains\n— Trouver des propriétés adaptées à votre budget\n— Répondre aux questions sur la résidence et les taxes\n— Organiser des visites\n\nDites-moi simplement ce que vous recherchez (par exemple : <i>\"Je cherche un appartement 2+1 à Alanya pour moins de 150 000 euros\"</i>) ou ouvrez le catalogue ci-dessous ! 👇"
            };

            const welcome = greetings[initialLang] || greetings['ru'];
            await sendMessage(token, chatId, welcome, { parse_mode: 'HTML' });
            await appendMessage({ session_id: sessionId, bot_id: botId, role: "assistant", content: welcome });
            console.log(`[Bot] Sent localized greeting (${initialLang}) to ${chatId}`);
            return; // STOP HERE for /start
        }

        // 2. Build Context
        const rules = "Общайся вежливо, показывай максимум 1 вариант объекта зараз. Ты эксперт недвижимости.";
        
        const { data: faqRows } = await supabase.from('faq').select('question, answer, i18n').order('sort_order', { ascending: true });
        const currentLang = existingUser?.lang_code || userInfo.language_code || 'ru';
        const companyInfoStr = faqRows?.map(r => {
            const q = r.i18n?.questions?.[currentLang] || r.i18n?.[currentLang]?.question || r.i18n?.ru?.question || r.question;
            const a = r.i18n?.answers?.[currentLang] || r.i18n?.[currentLang]?.answer || r.i18n?.ru?.answer || r.answer;
            return `Вопрос: ${q}\nОтвет: ${a}`;
        }).join("\n\n") || "";
        const agencyFiles = await handleGetAgencyInfo(currentLang);

        const botKnowledge = `[ПРАВИЛА]:\n${rules}\n\n[О КОМПАНИИ]:\n${companyInfoStr}\n\n[ФАЙЛЫ]:\n${agencyFiles}`;

        const history = await listMessages(sessionId, 10);
        const sortedHistory = (history || []).sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

        const messages: RoleMessage[] = [];
        for (const msg of sortedHistory) {
            if (msg.role === 'system' || !msg.content) continue;
            messages.push({ role: msg.role === 'assistant' ? 'assistant' : 'user', content: msg.content });
        }

        const lastMsg = sortedHistory[sortedHistory.length - 1];
        if (!lastMsg || lastMsg.content !== text) {
            messages.push({ role: "user", content: text });
        }

        // ==========================================
        // 3. ORCHESTRATOR (7-AGENT PIPELINE)
        // ==========================================
        sendChatAction(token, chatId, 'typing').catch(() => {});
        const plan = await runAnalyzerAgent(messages, botKnowledge);
        console.log(`[Bot] Orchestrator Plan:`, JSON.stringify(plan));

        let propertyContext = "База недвижимости не запрашивалась.";
        let leadContext = "";
        let unitsFound: any[] = [];
        let finalReplyText = "";

        // A. SEARCH AGENT
        if (plan.search_agent) {
            console.log("[Bot] 🔍 SEARCH AGENT TRIGGERED");
            let intent = plan.search_agent.transaction_type === "rent" ? "rent" : "sale";
            if (plan.search_agent.category === "land") intent = "land";
            if (plan.search_agent.category === "commercial") intent = "commercial";
            
            const searchParams = { ...plan.search_agent, intent };
            
            const searchTasks = [
                searchParams, 
                { ...searchParams, rooms: undefined }, 
                { ...searchParams, rooms: undefined, price_max: searchParams.price_max ? searchParams.price_max * 1.5 : undefined }
            ];

            for (let task of searchTasks) {
                try {
                    const rawResult = await handleSearchDatabase(task);
                    const parsed = JSON.parse(rawResult);

                    if (parsed.units && parsed.units.length > 0) {
                        const assistantHistory = messages.filter(m => m.role === "assistant").map(m => m.content).join(" ");
                        const uuidRegex = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi;
                        const shownIds = Array.from(assistantHistory.matchAll(uuidRegex)).map((m: any) => m[0]);

                        const newUnits = parsed.units.filter((u: any) => !shownIds.includes(u.id));
                        if (newUnits.length > 0) {
                            unitsFound = newUnits;
                            break;
                        } else if (parsed.units.length > 0) {
                            unitsFound = parsed.units;
                            break;
                        }
                    }
                } catch (e: any) {}
            }

            if (unitsFound.length > 0) {
                // ПРАВИЛО: ТОЛЬКО 1 ВАРИАНТ ЗА РАЗ
                propertyContext = JSON.stringify(unitsFound.slice(0, 1), null, 2);
            } else {
                propertyContext = "[ВНИМАНИЕ: ОБЪЕКТЫ ПО ЗАПРОСУ НЕ НАЙДЕНЫ. Скажи клиенту, что точных совпадений нет, и предложи альтернативу.]";
            }
        }

        // B. LEAD EXTRACTOR
        if (plan.lead_extractor_agent) {
            console.log("[Bot] 💼 LEAD EXTRACTOR TRIGGERED");
            const ext = plan.lead_extractor_agent;
            leadContext = `[ПРОФИЛЬ КЛИЕНТА]: ${ext.client_profile || "Неизвестно"}. Бюджет: ${ext.budget || "Не указан"}. Температура: ${ext.lead_temperature || "warm"}`;
            
            // Fix: Store human-readable address in the lead instead of a UUID
            let interested_units: string[] = [];
            if (unitsFound.length > 0) {
                const u = unitsFound[0];
                interested_units = [`${u.city}, ${u.address}`];
            }

            handleSaveLead({ 
                phone: manualPhone || ext.client_phone || userInfo.phone || "Unknown", 
                name: ext.client_name || userInfo.fullName || userInfo.username || "Client", 
                info: ext.client_profile || "Аналитика диалога", 
                budget: ext.budget, 
                temperature: ext.lead_temperature || "warm", 
                language: userInfo.language_code || "ru", 
                purpose: "НЕДВИЖИМОСТЬ",
                unit_id: unitsFound.length > 0 ? unitsFound[0].id : undefined,
                interested_units: interested_units.length > 0 ? interested_units : undefined,
                referrer_id: referrer_id || undefined
            } as any, chatId, userInfo.username).then(() => {
                // Schedule follow-up advertising message (2 min)
                scheduleFollowup(chatId, token, userInfo.language_code || 'ru').catch(() => {});
            }).catch(e => console.error("[Bot] Save Lead Error:", e));
        }

        // C. NOTIFIER AGENT
        if (plan.notifier_agent) {
            console.log("[Bot] 🚨 NOTIFIER AGENT TRIGGERED");
            
            // Fetch all staff members (founder, admin, manager)
            const { data: staffMembers } = await supabase
                .from("users")
                .select("telegram_id, role")
                .in("role", ["founder", "admin", "manager"]);
            
            if (staffMembers && staffMembers.length > 0) {
                // Activate Support Mode for client so their next messages are forwarded
                await supabase.from('users').update({ is_support_mode: true }).eq('telegram_id', parseInt(chatId));

                const name = userInfo.fullName || userInfo.username || "Client";
                const phoneText = manualPhone ? `\n📞 <b>Номер:</b> <code>${escapeHtml(manualPhone)}</code>` : "";
                const unit = unitsFound.length > 0 ? unitsFound[0] : null;
                const unitText = unit ? `\n🏠 <b>Объект:</b> ${escapeHtml(unit.title?.ru || unit.title || unit.city)}` : "";

                const alertMsg = `🔥 <b>ВНИМАНИЕ! (ИИ-БОТ)</b> 🔥\n\n👤 Пользователь: @${userInfo.username || chatId}\n👤 Имя: ${escapeHtml(name)}\n🆔 ID: <code>${chatId}</code>${phoneText}${unitText}\n💬 Причина: ${escapeHtml(plan.notifier_agent.alert_reason || "Вызов менеджера")}`;
                
                // Filtering recipients based on role logic from eSIM bot
                const recipients = staffMembers.filter(r => 
                    r.role === 'founder' || 
                    r.role === 'admin' || 
                    (r.role === 'manager' && String(r.telegram_id) === String(referrer_id))
                );

                for (const recipient of recipients) {
                    if (recipient.telegram_id) {
                        const { data: lastLead } = await supabase.from('leads').select('id').eq('user_id', parseInt(chatId)).order('created_at', { ascending: false }).limit(1).single();
                        
                        const buttons: any = {
                            inline_keyboard: [
                                [{ text: "✉️ Написать клиенту", callback_data: `contactuser_${chatId}` }]
                            ]
                        };

                        if (lastLead) {
                            buttons.inline_keyboard.push([
                                { text: "✅ Подтвердить сделку", callback_data: `deal_confirm_${lastLead.id}` },
                                { text: "❌ Отмена", callback_data: `deal_cancel_${lastLead.id}` }
                            ]);
                        }

                        // Add Dashboard button as last row
                        buttons.inline_keyboard.push([{ text: "В дашборд ↗️", url: "https://ai2b.app/app/stats" }]);

                        sendMessage(token, String(recipient.telegram_id), alertMsg, { 
                            parse_mode: 'HTML',
                            reply_markup: buttons
                        }).catch(() => {});
                    }
                }
            }
        }

        // D. PHOTO AGENT (Auto or Manual)
        if (plan.photo_agent?.target_unit_uuid) {
            console.log("[Bot] 📸 PHOTO AGENT TRIGGERED (Explicit UUID)");
            sendChatAction(token, chatId, 'upload_photo').catch(() => {});
            await handleGetPhotos({ unit_id: plan.photo_agent.target_unit_uuid }, token, chatId).catch(e => console.error(e));
        } else if (plan.search_agent && unitsFound.length > 0) {
            // Auto dispatch photo for the 1 shown property
            console.log("[Bot] 📸 PHOTO AGENT (Auto Trigger for found unit)");
            const displayedUnit = unitsFound[0];
            if (displayedUnit.id) {
                sendChatAction(token, chatId, 'upload_photo').catch(() => {});
                await handleGetPhotos({ unit_id: String(displayedUnit.id) }, token, chatId).catch(e => console.error(e));
            }
        }

        // E. WRITER AGENT
        if (plan.writer_agent) {
            console.log("[Bot] ✍️ WRITER AGENT TRIGGERED");
            sendChatAction(token, chatId, 'typing').catch(() => {});
            
            let wInstruction = plan.writer_agent.instruction || "Ответь на вопросы клиента.";
            if (unitsFound.length > 0) {
                wInstruction = `ВНИМАНИЕ: ОБЪЕКТ НАЙДЕН! 1) ОТВЕТЬ клиенту; 2) ПРЕЗЕНТУЙ 1 объект из базы; 3) Задай вовлекающий вопрос (CTA).\n\n${wInstruction}`;
            }

            const combinedInstruction = `[ИНСТРУКЦИЯ]: ${wInstruction}\n${leadContext}`;
            // Use the unified SaleWriter logic for crafting the response natively in ru/en
            finalReplyText = await runSaleWriterAgent(messages, combinedInstruction, propertyContext);
        } else {
            // Orchestrator fallback
            finalReplyText = "One second, I am checking the information...";
        }

        // F. TRANSLATOR AGENT
        if (finalReplyText) {
            console.log("[Bot] 🌍 TRANSLATOR AGENT TRIGGERED");
            const detectedLang = plan.language || userInfo.language_code || "ru"; 
            
            // Update user language in DB if it changed
            if (plan.language && plan.language !== existingUser?.lang_code) {
                await supabase.from('users').update({ lang_code: plan.language }).eq('telegram_id', parseInt(chatId));
            }

            try {
                finalReplyText = await runClientTranslatorAgent(finalReplyText, detectedLang, messages);
            } catch (translError) {
                console.error("[Bot] Translation error, running fallback base text.", translError);
            }
        }

        // G. FINAL SEND
        if (finalReplyText) {
            console.log("[Bot] Sending final text to Telegram...");
            await sendMessage(token, chatId, finalReplyText);

            let dbStoreText = finalReplyText;
            if (plan.search_agent && unitsFound.length > 0) {
                dbStoreText += `\n\n[HIDDEN_SYSTEM_ID: ${unitsFound[0].id}]`;
            }
            // If the user explicitly requested photos, keep the uuid history active too if not found
            if (plan.photo_agent?.target_unit_uuid && unitsFound.length === 0) {
                dbStoreText += `\n\n[HIDDEN_SYSTEM_ID: ${plan.photo_agent.target_unit_uuid}]`;
            }
            await appendMessage({ session_id: sessionId, bot_id: botId, role: "assistant", content: dbStoreText });
        }

        console.log("[Bot] Turn complete.");

    } catch (globalErr: any) {
        console.error("CRITICAL MESSAGE HANDLER ERROR:", globalErr);
        const errorDetail = globalErr.message ? `: ${globalErr.message}` : "";
        const errorMsg = `A system error occurred${errorDetail}. We are already fixing it!`;
        const translatedError = await runClientTranslatorAgent(errorMsg, userInfo.language_code || "ru", []);
        await sendMessage(token, chatId, translatedError).catch(() => { });
    }
}
