'use client';

import React, { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabaseClient';
import CatalogView from './catalog/CatalogView';
import ReferralView from './referral/ReferralView';
import StatsView from './dashboard/StatsView';
import FaqView from './faq/FaqView';
import ClientFaqView from './faq/ClientFaqView';
import UnitsView from './properties/UnitsView';

declare global {
    interface Window {
        Telegram: any;
    }
}

const BOT_USERNAME = process.env.NEXT_PUBLIC_BOT_USERNAME || 'ai2b_app_bot';

const translations: Record<string, any> = {
    ru: {
        loading: 'Загрузка системы...',
        loginTitle: 'Auth Terminal',
        loginDesc: 'Авторизация в системе управления',
        loginPlaceholder: 'Telegram ID',
        loginBtn: 'Войти',
        tabCatalog: 'Каталог',
        tabBonuses: 'Бонусы',
        tabStats: 'Статистика',
        tabLeads: 'Лиды',
        tabUnits: 'Объекты',
        tabFaq: 'FAQ',
        adminMode: 'Admin Mode',
        managerMode: 'Manager Mode',
        clientMode: 'Client Access',
    },
    en: {
        loading: 'Initializing...',
        loginTitle: 'Auth Terminal',
        loginDesc: 'Management system authorization',
        loginPlaceholder: 'Telegram ID',
        loginBtn: 'Login',
        tabCatalog: 'Catalog',
        tabBonuses: 'Bonuses',
        tabStats: 'Statistics',
        tabLeads: 'Leads',
        tabUnits: 'Units',
        tabFaq: 'FAQ',
        adminMode: 'Admin Mode',
        managerMode: 'Manager Mode',
        clientMode: 'Client Access',
    },
    tr: {
        loading: 'Başlatılıyor...',
        loginTitle: 'Auth Terminal',
        loginDesc: 'Yönetim sistemi yetkilendirmesi',
        loginPlaceholder: 'Telegram ID',
        loginBtn: 'Giriş',
        tabCatalog: 'Katalog',
        tabBonuses: 'Bonuslar',
        tabStats: 'İstatistik',
        tabLeads: 'Başvurular',
        tabUnits: 'Mülkler',
        tabFaq: 'SSS',
        adminMode: 'Admin Mode',
        managerMode: 'Manager Mode',
        clientMode: 'Client Access',
    },
    de: {
        loading: 'Initialisierung...',
        loginTitle: 'Auth Terminal',
        loginDesc: 'Autorisierung des Managementsystems',
        loginPlaceholder: 'Telegram ID',
        loginBtn: 'Einloggen',
        tabCatalog: 'Katalog',
        tabBonuses: 'Boni',
        tabStats: 'Statistik',
        tabLeads: 'Anfragen',
        tabUnits: 'Objekte',
        tabFaq: 'FAQ',
        adminMode: 'Admin-Modus',
        managerMode: 'Manager-Modus',
        clientMode: 'Client-Zugriff',
    },
    es: {
        loading: 'Iniciando...',
        loginTitle: 'Terminal de Aut.',
        loginDesc: 'Autorización del sistema de gestión',
        loginPlaceholder: 'Telegram ID',
        loginBtn: 'Entrar',
        tabCatalog: 'Catálogo',
        tabBonuses: 'Bonos',
        tabStats: 'Estadísticas',
        tabLeads: 'Clientes',
        tabUnits: 'Unidades',
        tabFaq: 'FAQ',
        adminMode: 'Modo Admin',
        managerMode: 'Modo Manager',
        clientMode: 'Acceso Cliente',
    },
    ar: {
        loading: 'جاري التحميل...',
        loginTitle: 'محطة التفويض',
        loginDesc: 'تفويض نظام الإدارة',
        loginPlaceholder: 'Telegram ID',
        loginBtn: 'تسجيل الدخول',
        tabCatalog: 'الكتالوج',
        tabBonuses: 'المكافآت',
        tabStats: 'الإحصائيات',
        tabLeads: 'الطلبات',
        tabUnits: 'الوحدات',
        tabFaq: 'الأسئلة الشائعة',
        adminMode: 'وضع المسؤول',
        managerMode: 'وضع المدير',
        clientMode: 'وصول العميل',
    },
    fr: {
        loading: 'Initialisation...',
        loginTitle: 'Terminal Auth',
        loginDesc: 'Autorisation du système de gestion',
        loginPlaceholder: 'Telegram ID',
        loginBtn: 'Connexion',
        tabCatalog: 'Catalogue',
        tabBonuses: 'Bonus',
        tabStats: 'Statistiques',
        tabLeads: 'Prospects',
        tabUnits: 'Unités',
        tabFaq: 'FAQ',
        adminMode: 'Mode Admin',
        managerMode: 'Mode Manager',
        clientMode: 'Accès Client',
    },
};

export default function MiniAppDispatcher() {
    const [user, setUser] = useState<any>(null);
    const [loginInputId, setLoginInputId] = useState('');
    const [loading, setLoading] = useState(true);
    const [lang, setLang] = useState('ru');
    const [activeTab, setActiveTab] = useState<string>('catalog');
    const [showLangDropdown, setShowLangDropdown] = useState(false);
    const [debugInfo, setDebugInfo] = useState<string>('');

    const t = translations[lang] || translations['ru'];

    useEffect(() => {
        const init = async () => {
            setDebugInfo('Checking SDK...');
            
            // Force inject if missing
            if (!window.Telegram) {
                console.log('[AUTH] Script missing, injecting local...');
                const s = document.createElement('script');
                s.src = '/telegram-web-app.js';
                s.async = false;
                document.head.appendChild(s);
            }

            // Connection test
            let dbStatus = 'Wait';
            try {
                const { error } = await supabase.from('users').select('count', { count: 'exact', head: true }).limit(1);
                dbStatus = error ? `Err: ${error.message}` : 'OK';
            } catch (e) {
                dbStatus = 'Fail';
            }

            let tg: any = window.Telegram?.WebApp || (window as any).parent?.Telegram?.WebApp;
            
            // 1. Wait for SDK
            if (!tg) {
                for (let i = 0; i < 60; i++) {
                    await new Promise(r => setTimeout(r, 100));
                    tg = window.Telegram?.WebApp || (window as any).parent?.Telegram?.WebApp;
                    if (tg) break;
                }
            }

            if (tg) {
                setDebugInfo(`SDK OK | DB: ${dbStatus}`);
                try {
                    tg.ready();
                    tg.expand();
                    tg.backgroundColor = '#0a0a0c';
                    tg.headerColor = '#0a0a0c';
                } catch (e) {}
            } else {
                setDebugInfo(`SDK Missing | DB: ${dbStatus} | W:${!!window.Telegram} P:${!!(window as any).parent?.Telegram}`);
            }

            let tgUser: any = null;
            const unsafeKeys = tg?.initDataUnsafe ? Object.keys(tg.initDataUnsafe).join(',') : 'none';
            const hasUserInUnsafe = !!tg?.initDataUnsafe?.user;
            
            // 2. Try initDataUnsafe.user
            for (let i = 0; i < 15; i++) {
                if (tg?.initDataUnsafe?.user?.id) {
                    tgUser = tg.initDataUnsafe.user;
                    break;
                }
                await new Promise(r => setTimeout(r, 200));
            }

            // 3. Fallback: Parse from raw initData string
            if (!tgUser?.id && tg?.initData) {
                try {
                    const searchParams = new URLSearchParams(tg.initData);
                    const userStr = searchParams.get('user');
                    if (userStr) {
                        tgUser = JSON.parse(decodeURIComponent(userStr));
                    }
                } catch (e) {
                    console.error('Failed to parse initData user', e);
                }
            }

            // 4. Fallback: check localStorage
            if (!tgUser?.id) {
                const storedUser = localStorage.getItem('tgUser');
                if (storedUser) tgUser = JSON.parse(storedUser);
            }

            // 5. Final Debug Info
            const debugMsg = `SDK:OK | DB:${dbStatus} | UserInUnsafe:${hasUserInUnsafe} | Keys:${unsafeKeys} | DataLen:${tg?.initData?.length || 0}`;
            setDebugInfo(debugMsg);

            let referrerId: number | null = null;
            if (tg?.initDataUnsafe?.start_param) {
                const ref = parseInt(tg.initDataUnsafe.start_param);
                if (!isNaN(ref)) referrerId = ref;
            }

            if (tgUser?.id) {
                // Persist for next time
                localStorage.setItem('tgUser', JSON.stringify(tgUser));
                
                const supportedLangs = ['ru', 'en', 'tr', 'de', 'es', 'ar', 'fr'];
                const userLang = tgUser.language_code?.toLowerCase();
                if (userLang && supportedLangs.includes(userLang)) {
                    setLang(userLang);
                }
                await fetchUserData(tgUser.id, `${tgUser.first_name || ''} ${tgUser.last_name || ''}`.trim(), tgUser.username, referrerId);
            } else {
                const params = new URLSearchParams(window.location.search);
                const uid = params.get('uid');
                const ref = params.get('ref');
                if (ref && !isNaN(parseInt(ref))) referrerId = parseInt(ref);

                if (uid && !isNaN(parseInt(uid))) {
                    await fetchUserData(parseInt(uid), undefined, undefined, referrerId);
                } else {
                    setLoading(false);
                }
            }
        };
        init();
    }, []);

    const fetchUserData = async (tgId: number, fullName?: string, username?: string, referrerId?: number | null) => {
        try {
            console.log('[AUTH] Fetching/Syncing user:', tgId);
            setLoading(true);
            
            // 1. Check if user exists
            const { data: existingUser, error: fetchError } = await supabase
                .from('users')
                .select('role, referrer_id')
                .eq('telegram_id', tgId)
                .maybeSingle();

            if (fetchError) console.error('[AUTH] Fetch error:', fetchError);

            const roleToSet = existingUser?.role || 'client';
            let finalReferrer = existingUser ? existingUser.referrer_id : (referrerId || null);

            // 2. Validate Referrer exists (FK constraint)
            if (finalReferrer && !existingUser) {
                const { data: refExists } = await supabase
                    .from('users')
                    .select('telegram_id')
                    .eq('telegram_id', finalReferrer)
                    .maybeSingle();
                
                if (!refExists) {
                    console.warn('[AUTH] Referrer ID not found in DB, setting to null:', finalReferrer);
                    finalReferrer = null;
                }
            }

            const userData: any = {
                telegram_id: tgId,
                username: username || fullName || `user_${tgId}`,
                full_name: fullName || username || '',
                role: roleToSet,
                lang_code: lang,
                referrer_id: finalReferrer,
            };

            console.log('[AUTH] Upserting user data:', userData);
            const { data: currentUser, error: upsertError } = await supabase
                .from('users')
                .upsert(userData, { onConflict: 'telegram_id' })
                .select()
                .maybeSingle();

            if (upsertError) {
                console.error('[AUTH] Upsert failed:', upsertError);
                // Fallback: if upsert fails (e.g. database error), at least set basic user state to allow entry
                setUser({
                    telegram_id: tgId,
                    role: roleToSet,
                    full_name: fullName || username || 'User',
                    username: username || 'user'
                });
            } else if (currentUser) {
                console.log('[AUTH] Current user state:', currentUser);
                setUser(currentUser);
                if (currentUser.role !== 'client') {
                    setActiveTab('stats');
                }
            } else {
                console.warn('[AUTH] No user returned from upsert, using fallback state');
                setUser({ telegram_id: tgId, role: roleToSet });
            }
        } catch (err) {
            console.error('[AUTH] Critical Error in fetchUserData:', err);
            // Emergency fallback
            setUser({ telegram_id: tgId, role: 'client' });
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center min-h-screen bg-background">
                <div className="w-16 h-16 relative">
                    <div className="absolute inset-0 border-4 border-primary/20 rounded-full" />
                    <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin" />
                </div>
                <p className="mt-6 text-[10px] font-black text-outline uppercase tracking-[0.3em] animate-pulse">{t.loading}</p>
                <p className="mt-2 text-[8px] text-outline-variant uppercase font-mono">{debugInfo}</p>
            </div>
        );
    }

    if (!user) {
        return (
            <div className="bg-background min-h-screen flex items-center justify-center p-6">
                <div className="card-premium p-10 w-full max-w-sm space-y-8 relative overflow-hidden neon-glow">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-[60px]" />
                    <div className="text-center space-y-4">
                        <div className="w-20 h-20 bg-primary/10 rounded-3xl mx-auto flex items-center justify-center border border-primary/20">
                            <span className="material-symbols-outlined text-primary text-[40px] font-thin">lock_open</span>
                        </div>
                        <h1 className="text-2xl font-black text-on-background tracking-tight">{t.loginTitle}</h1>
                        <p className="text-[10px] text-outline font-bold uppercase tracking-widest">{t.loginDesc}</p>
                    </div>
                    <div className="space-y-4">
                        <input
                            type="number"
                            value={loginInputId}
                            onChange={(e) => setLoginInputId(e.target.value)}
                            placeholder={t.loginPlaceholder}
                            className="input-field text-center font-black tracking-widest text-xl"
                        />
                        <button
                            onClick={() => fetchUserData(parseInt(loginInputId))}
                            className="btn-primary w-full"
                        >
                            {t.loginBtn}
                        </button>
                    </div>
                    <div className="text-center">
                        <p className="text-[8px] text-outline-variant font-mono uppercase tracking-widest">{debugInfo}</p>
                    </div>
                </div>
            </div>
        );
    }

    const isAdmin = user?.role === 'founder' || user?.role === 'admin';
    const isStaff = isAdmin || user?.role === 'manager';

    return (
        <div className="min-h-screen pb-32 bg-background">
            {/* MD3 Header */}
            <header className="px-6 pt-10 pb-4 flex justify-between items-center relative">
                <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-[100px] -z-10" />
                <div>
                    <h1 className="text-3xl font-black text-on-background tracking-tighter uppercase">
                        Emedeo
                    </h1>
                </div>
                
                {/* Lang Switcher */}
                <button
                    onClick={() => setShowLangDropdown(!showLangDropdown)}
                    className="w-10 h-10 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10 active:scale-90 transition-all hover:bg-white/10"
                >
                    <span className="material-symbols-outlined text-[20px] text-zinc-400 font-black">translate</span>
                </button>

                {showLangDropdown && (
                    <div className="absolute top-24 right-6 w-48 bg-surface-container-high/90 backdrop-blur-2xl border border-white/10 rounded-3xl shadow-2xl z-[1000] overflow-hidden py-2 animate-in fade-in zoom-in duration-200">
                        {['ru', 'en', 'tr', 'de', 'es', 'ar', 'fr'].map((l) => (
                            <button
                                key={l}
                                onClick={() => { setLang(l); setShowLangDropdown(false); }}
                                className={`w-full text-left px-5 py-4 text-xs font-black uppercase tracking-widest flex items-center justify-between ${lang === l ? 'text-primary bg-primary/5' : 'text-zinc-500 hover:bg-white/5'}`}
                            >
                                <span>
                                    {l === 'ru' ? 'Русский' : 
                                     l === 'en' ? 'English' : 
                                     l === 'tr' ? 'Türkçe' : 
                                     l === 'de' ? 'Deutsch' : 
                                     l === 'es' ? 'Español' : 
                                     l === 'ar' ? 'العربية' : 'Français'}
                                </span>
                                {lang === l && <span className="material-symbols-outlined text-[16px]">check_circle</span>}
                            </button>
                        ))}
                    </div>
                )}
            </header>

            <main className="px-5 pt-4 max-w-2xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500">
                {activeTab === 'catalog' && <CatalogView lang={lang} />}
                {activeTab === 'bonuses' && <ReferralView user={user} lang={lang} />}
                {activeTab === 'stats' && <StatsView user={user} lang={lang} />}
                {activeTab === 'units' && <UnitsView lang={lang} />}
                {activeTab === 'faq' && (isAdmin ? <FaqView lang={lang} /> : <ClientFaqView lang={lang} />)}
            </main>

            {/* Rectangular Nav Bar at the absolute bottom */}
            <nav className="fixed bottom-0 inset-x-0 z-[100]">
                <div className="w-full bg-surface-container-high/80 backdrop-blur-2xl border-t border-white/5 p-2 flex justify-around items-center shadow-[0_-10px_30px_rgba(0,0,0,0.3)]">
                    <NavTab icon="explore" label={t.tabCatalog} active={activeTab === 'catalog'} onClick={() => setActiveTab('catalog')} color={isStaff ? 'zinc' : 'primary'} />
                    <NavTab icon="redeem" label={t.tabBonuses} active={activeTab === 'bonuses'} onClick={() => setActiveTab('bonuses')} color={isStaff ? 'zinc' : 'primary'} />
                    
                    {isStaff && (
                        <NavTab icon="analytics" label={t.tabStats} active={activeTab === 'stats'} onClick={() => setActiveTab('stats')} color="primary" />
                    )}

                    {isAdmin && (
                        <NavTab icon="apartment" label={t.tabUnits} active={activeTab === 'units'} onClick={() => setActiveTab('units')} color="primary" />
                    )}
                    
                    <NavTab icon="help" label={t.tabFaq} active={activeTab === 'faq'} onClick={() => setActiveTab('faq')} color={isStaff ? 'primary' : 'zinc'} />
                </div>
                {/* Safe area padding for modern iPhones */}
                <div className="h-[env(safe-area-inset-bottom)] bg-surface-container-high/80 backdrop-blur-2xl" />
            </nav>
        </div>
    );
}

function NavTab({ icon, label, active, onClick, color = 'primary' }: any) {
    return (
        <button
            onClick={onClick}
            className={`flex flex-col items-center gap-1 py-1 rounded-2xl transition-all duration-300 flex-1 ${active ? '' : 'opacity-40 hover:opacity-100'}`}
        >
            <div className={`w-full max-w-[56px] h-8 rounded-xl flex items-center justify-center transition-all ${active ? (color === 'primary' ? 'bg-primary text-black shadow-[0_0_15px_rgba(208,188,255,0.4)]' : 'bg-white text-black') : 'text-zinc-500'}`}>
                <span className="material-symbols-outlined text-[20px] font-black" style={{ fontVariationSettings: active ? "'FILL' 1" : "'FILL' 0" }}>
                    {icon}
                </span>
            </div>
            <span className={`text-[9px] font-black uppercase tracking-[0.1em] mt-1 ${active ? 'text-white' : 'text-zinc-600'}`}>{label}</span>
        </button>
    );
}

